const express = require('express');
const path = require('path');
const db = require('./db'); // MySQL 数据库连接
const app = express();

// 设置静态文件目录
app.use(express.static(path.join(__dirname, 'public')));

// 首页 - 返回 index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// 搜索页面 - 返回 search.html
app.get('/search', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'search.html'));
});
// API：获取所有类别
app.get('/api/categories', (req, res) => {
    const query = 'SELECT CATEGORY_ID, NAME FROM CATEGORY';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// API：获取所有组织者
app.get('/api/organizers', (req, res) => {
    const query = 'SELECT DISTINCT ORGANIZATION FROM FUNDRAISER';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// API：获取所有城市
app.get('/api/cities', (req, res) => {
    const query = 'SELECT DISTINCT CITY FROM FUNDRAISER';
    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});


// 筹款活动详情页面 - 返回 fundraiser.html
app.get('/fundraiser/:id', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'fundraiser.html'));
});

// 获取所有正在进行的筹款活动
app.get('/api/fundraisers', (req, res) => {
    const query = `
        SELECT f.FUNDRAISER_ID, f.ORGANIZATION, f.TITLE, f.TARGET_FUNDING, f.CURRENT_FUNDING, f.CITY, f.EVENT_DATE, c.NAME AS CATEGORY_NAME 
        FROM FUNDRAISER f 
        JOIN CATEGORY c ON f.CATEGORY_ID = c.CATEGORY_ID
        WHERE f.CURRENT_FUNDING < f.TARGET_FUNDING`;

    db.query(query, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});
// 搜索筹款活动
app.get('/api/search', (req, res) => {
    const { organizers, cities, categories } = req.query;

    let query = `
        SELECT f.FUNDRAISER_ID, f.ORGANIZATION, f.TITLE, f.TARGET_FUNDING, f.CURRENT_FUNDING, f.CITY, f.EVENT_DATE 
        FROM FUNDRAISER f 
        WHERE 1=1`;

    const queryParams = [];

    // 处理选中的组织者
    if (organizers && organizers.length > 0) {
        query += ' AND f.ORGANIZATION IN (?)';
        queryParams.push(organizers.split(','));
    }

    // 处理选中的城市
    if (cities && cities.length > 0) {
        query += ' AND f.CITY IN (?)';
        queryParams.push(cities.split(','));
    }

    // 处理选中的类别
    if (categories && categories.length > 0) {
        query += ' AND f.CATEGORY_ID IN (?)';
        queryParams.push(categories.split(','));
    }

    db.query(query, queryParams, (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results);
    });
});

// 获取单个筹款活动详情
app.get('/api/fundraiser/:id', (req, res) => {
    const fundraiserId = req.params.id;
    const query = `
        SELECT f.FUNDRAISER_ID, f.ORGANIZATION, f.TITLE, f.TARGET_FUNDING, f.CURRENT_FUNDING, f.CITY, f.EVENT_DATE, c.NAME AS CATEGORY_NAME 
        FROM FUNDRAISER f 
        JOIN CATEGORY c ON f.CATEGORY_ID = c.CATEGORY_ID
        WHERE f.FUNDRAISER_ID = ?`;

    db.query(query, [fundraiserId], (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }
        res.json(results[0]);
    });
});

// 服务器监听端口
app.listen(3000, () => {
    console.log('服务器运行在 http://localhost:3000');
});