const mysql = require('mysql');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // MySQL 用户名
    password: '18551522908',  // MySQL 密码
    database: 'crowdfunding_db'
});

connection.connect((err) => {
    if (err) {
        console.error('连接数据库失败: ' + err.stack);
        return;
    }
    console.log('成功连接数据库');
});

module.exports = connection;